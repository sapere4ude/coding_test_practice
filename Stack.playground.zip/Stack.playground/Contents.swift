// Stack 구조 (2020.11.25 유재준)

import Foundation

public struct Stack<Element> {
    private var storage: [Element] = []
    public init() { }
    
    public mutating func push(_ element: Element) {
        storage.append(element) // ()안에는 파라미터 이름이 들어와야함
    }
    
    @discardableResult // 결과를 사용하던 사용하지않던 상관X. Warning 뜨지않게 사용하는 것
    public mutating func pop() -> Element? {
        return storage.popLast()
    }
}

extension Stack: CustomStringConvertible {
    public var description: String {
        let topDivider = "----top----\n"
        let bottomDivider = "\n--------"
        
        let stackElements = storage
            .map { "\($0)" }
            .reversed()
            .joined(separator: "\n")    // joined 메서드로 인해 stackElements의 type은 String이 된다.
        type(of: stackElements)
        return topDivider + stackElements + bottomDivider
    }
}


  var stack = Stack<Int>()
  stack.push(1)
  stack.push(2)
  stack.push(3)
  stack.push(4)

  print(stack)
  
  if let poppedElement = stack.pop() {
    assert(4 == poppedElement)
    print("Popped: \(poppedElement)")
  }

